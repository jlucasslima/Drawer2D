/**
 * Cria um tipo enumerado (enum)
 * 
 * Integrantes do Grupo:
 * - Jo�o Lucas de Lima Souza - RA00360044
 * - Pedro Chagas Neves de Farias Nascimento - RA00359511
 * - Guilherme Pereira de Rivoredo - RA00359303
 * - Eduardo Achkar avancini - RA00359889
 * 
 * @author Julio Arakaki (Adapta��o)
 * @version 20260818
 */
public enum TipoPrimitivo {
    NENHUM, PONTO, RETA, CIRCULO, RETANGULO, TRIANGULO, SELECAO, ESPELHO
}